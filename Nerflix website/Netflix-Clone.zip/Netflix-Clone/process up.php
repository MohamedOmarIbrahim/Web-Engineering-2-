<?php
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $db = "netflix";
    $conn = new mysqli($dbhost, $dbuser, $dbpass, $db);
    if(isset($_POST['submit'])){
    $firstname = $_POST['firstname'];  
    $lastname = $_POST['lastname'];    
    $email = $_POST['email'];
    $password = $_POST['password'];

     $sql = "INSERT INTO sign_up (firstname, lastname, email, password) VALUES ('$firstname', '$lastname','$email','$password')";
    $result = mysqli_query($conn, $sql);
        if($result){
           echo "Successfully login";
             header("Location: index in.php");
             exit();

        } else {
           echo "wrong";
        }
    }
?>