<?php
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $db = "netflix";
    $conn = new mysqli($dbhost, $dbuser, $dbpass, $db);
    if(isset($_POST['submit'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM sign_up WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) > 0){
           echo "Successfully login";
             header("Location: index home.html");
             exit();

        } else {
           echo "wrong";
        }
    }
?>