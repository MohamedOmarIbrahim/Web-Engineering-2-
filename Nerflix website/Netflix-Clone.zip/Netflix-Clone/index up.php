<!DOCTYPE html>
<!-- Coding By CodingNepal - www.codingnepalweb.com -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Netflix Login Page | CodingNepal</title>
    <link rel="stylesheet" href="style in & up.css">
</head>
<body>
    <nav>
        <a href="index.php"><img src="images/logo.svg" alt="logo"></a>
    </nav>
    <div class="form-wrapper">
        <h2>Sign Up</h2>
        <form method="POST" action="process up.php">
            <div class="form-control">
                <input type="text" name="firstname" required>
                <label>First name</label>
            </div>
            <div class="form-control">
                <input type="text" name="lastname" required>
                <label>Last name</label>
            </div>
            <div class="form-control">
                <input type="text" name="email" required>
                <label>Email</label>
            </div>
            <div class="form-control">
                <input type="password" name="password" required>
                <label>Password</label>
            </div>
            <button type="submit"  name="submit" value="submit">Sign Up</button>
        </form>
        <small>
            This page is protected by Google reCAPTCHA to ensure you're not a bot. 
            <a href="#">Learn more.</a>
        </small>
    </div>
</body>
</html>